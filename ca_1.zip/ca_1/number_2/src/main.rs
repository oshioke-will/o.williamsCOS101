//Rust program to compute gross salries and net pays
use std::io;


fn main() {
	println!("Employee salary calculator!");

{
	let mut a = String::new();
		//inputs the manes
	println!("Please input the name of the employee!!");
	let mut name = String::new();
	io::stdin().read_line(&mut name).expect("Failed to read input");

	//Inputs number of hours employee has worked
	println!("Enter the employee's number of hours worked");
	let mut hours = String::new();
	io::stdin().read_line(&mut hours).expect("Failed to read input");
	let hours:f32 = hours.trim().parse().expect("Input is too low as a salary");

 	if hours <= 40.0
 	{
 		let a:f32 = 3000.0 * hours;
 	}
	else if hours > 40.0
	{
		let a:f32 = 4500.0 * hours;
	}
	
	if a > 100000.0
	{
		let a:f32 = 2000.0 - a;
		println!("The individual's net pay is: {}", a);
	}

}


}